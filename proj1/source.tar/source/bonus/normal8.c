#include <stdio.h>

int main(int argc,char *argv[]){
	printf("This is normal8 program\n");
	return 0;
}
