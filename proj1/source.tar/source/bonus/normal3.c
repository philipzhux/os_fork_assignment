#include <stdio.h>

int main(int argc,char *argv[]){
	printf("This is normal3 program\n");
	return 0;
}
